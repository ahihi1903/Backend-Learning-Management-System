export default function asyncHandler(fn) {
  return async (req, res, next) => {
    try {
      await fn(req, res, next);
    } catch (error) {
      next(error); //đẩy lỗi xuống errorHandler
    }
  };
}
