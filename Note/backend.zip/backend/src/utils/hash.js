import bcrypt from "bcrypt";

export async function hashPassword(password) {
  //hàm băm
  return await bcrypt.hash(password, 10);
}

export async function comparePassword(password, hashed) {
  //hàm so sánh
  return await bcrypt.compare(password, hashed);
}
